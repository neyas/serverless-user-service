
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'neyasawssls',
  applicationName: 'myapp',
  appUid: 'C6ktsWVwq1kbcHFht8',
  orgUid: 'b5ad3ecd-cef5-4834-b381-70aa11c21cf2',
  deploymentUid: 'e6e2774b-cd6b-4631-bf34-23715b7f2c57',
  serviceName: 'user-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'user-service-dev-loginUser', timeout: 6 };

try {
  const userHandler = require('./src/functions/loginUser.js');
  module.exports.handler = serverlessSDK.handler(userHandler.loginUser, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}